from .Flatten import Flatten,FlattenM
from .Maxpool import AdaptiveAvgPool2d,MaxPool2d
from .Dropout import Dropout
from .ZeroPad2d import ZeroPad2d
from .Upsample import Upsample