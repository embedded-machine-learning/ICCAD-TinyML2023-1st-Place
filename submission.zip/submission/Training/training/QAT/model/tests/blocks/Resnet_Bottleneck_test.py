import warnings

def test_Resnet_Bollteneck():
    warnings.warn('Test not implemented')