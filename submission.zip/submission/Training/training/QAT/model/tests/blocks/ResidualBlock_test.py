import warnings

def test_ResidualBlock():
    warnings.warn('Test not implemented')
     